# filepath: /home/selph/Documents/Dashboard/src/routes/main.py
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from src.models import db, User, Note, NoteContent, Folder, Tag, Bookmark
from src.utils.general_utils import get_directory_info, get_database_info
from datetime import datetime, timedelta
import os
import logging

bp = Blueprint('main', __name__)

logging.basicConfig(level=logging.INFO)

@bp.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@bp.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    user = User.query.filter_by(username=username).first()
    
    if user is None or not user.check_password(password):
        flash('Invalid username or password')
        return redirect(url_for('main.index'))
    
    login_user(user)
    flash('Logged in successfully.')
    return redirect(url_for('main.index'))

@bp.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    confirm_password = request.form['confirm_password']
    
    if password != confirm_password:
        flash('Passwords do not match!')
        return redirect(url_for('main.index'))
    
    existing_user = User.query.filter_by(username=username).first()
    if existing_user:
        flash('Username already exists!')
        logging.info(f"Attempt to register with existing username: {username}")
        return redirect(url_for('main.index'))
    
    new_user = User(username=username)
    new_user.set_password(password)
    db.session.add(new_user)
    db.session.commit()
    
    login_user(new_user)
    logging.info(f"New user registered: {username}")
    return redirect(url_for('main.dashboard'))

@bp.route('/logout', methods=['POST'])
@login_required
def logout():
    current_user.logged_in = False
    db.session.commit()
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('main.index'))

@bp.route('/dashboard')
@login_required
def dashboard():
    directory_info = get_directory_info('/home/selph/Documents/Dashboard')
    database_info = get_database_info()
    return render_template('dashboard.html', directory_info=directory_info, database_info=database_info)

@bp.route('/bookmarks_manager')
@login_required
def bookmarks_manager():
    return render_template('bookmarks_manager.html')

@bp.route('/notes_manager')
@login_required
def notes_manager():
    notes = Note.query.all()
    return render_template('notes_manager.html', notes=notes)

@bp.route('/note_editor')
@login_required
def note_editor():
    return render_template('note_editor.html')

@bp.route('/save_note', methods=['POST'])
@login_required
def save_note():
    title = request.form['title']
    content = request.form['content']
    tag = request.form['tag']
    
    if len(content) > 65535:  # Assuming the content field can store up to 65535 characters
        # Save the note as a plain text file
        note_path = f'/home/selph/Documents/Dashboard/user/notes/{title}.txt'
        with open(note_path, 'w') as file:
            file.write(content)
        new_note = Note(title=title, path=note_path, tag=tag)
    else:
        # Save the note in the database
        note_content = NoteContent(content=content)
        db.session.add(note_content)
        db.session.commit()
        new_note = Note(title=title, content_id=note_content.id, tag=tag)
    
    db.session.add(new_note)
    db.session.commit()
    
    flash('Note saved successfully!')
    return redirect(url_for('main.notes_manager'))

@bp.route('/passwords_manager')
@login_required
def passwords_manager():
    return render_template('passwords_manager.html')