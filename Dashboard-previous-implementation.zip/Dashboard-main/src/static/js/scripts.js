// filepath: /home/selph/Documents/Dashboard/src/static/js/scripts.js
document.addEventListener('DOMContentLoaded', function () {
  const sidebar = document.getElementById('sidebar');
  const sidebarCollapse = document.getElementById('sidebarCollapse');

  // Toggle sidebar on button click
  sidebarCollapse.addEventListener('click', function () {
      sidebar.classList.toggle('active');
  });

  // Close sidebar if clicked outside
  document.addEventListener('click', function (event) {
      if (!sidebar.contains(event.target) && !sidebarCollapse.contains(event.target)) {
          sidebar.classList.remove('active');
      }
  });

  // Handle user icon click for login/logout
  const userIcon = document.getElementById('userIcon');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const logoutForm = document.getElementById('logoutForm');
  const showLoginFormButton = document.getElementById('showLoginForm');
  const showRegisterFormButton = document.getElementById('showRegisterForm');

  if (userIcon) {
      userIcon.addEventListener('click', function () {
          const isLoggedIn = userIcon.getAttribute('data-logged-in') === 'True';
          if (isLoggedIn) {
              // Show logout form
              loginForm.classList.add('d-none');
              registerForm.classList.add('d-none');
              logoutForm.classList.remove('d-none');
          } else {
              // Show login form
              loginForm.classList.remove('d-none');
              registerForm.classList.add('d-none');
              logoutForm.classList.add('d-none');
          }
      });
  }

  // Show login form
  if (showLoginFormButton) {
      showLoginFormButton.addEventListener('click', function () {
          loginForm.classList.remove('d-none');
          registerForm.classList.add('d-none');
      });
  }

  // Show register form
  if (showRegisterFormButton) {
      showRegisterFormButton.addEventListener('click', function () {
          loginForm.classList.add('d-none');
          registerForm.classList.remove('d-none');
      });
  }

  // Validate register form
  if (registerForm) {
      registerForm.addEventListener('submit', function (event) {
          const registerPassword = document.getElementById('registerPassword');
          const confirmPassword = document.getElementById('confirmPassword');
          if (registerPassword.value !== confirmPassword.value) {
              event.preventDefault();
              alert('Passwords do not match!');
          }
      });
  }
});